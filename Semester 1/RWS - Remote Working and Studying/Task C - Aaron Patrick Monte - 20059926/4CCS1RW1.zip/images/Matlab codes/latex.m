clear;
clc;
x = linspace(0,2.5, 1000);
x1 = linspace(0,6, 1000);
y_vert1 = linspace(0, 2, 1000);
y_vert2 = linspace(0, 4, 1000);
x_vert1 = linspace(2, 2, 1000);
x_vert2 = linspace(4, 4, 1000);

y = x.^2;
y1 =  x1.^0.5;

x_tan = linspace(1.5,2.5, 1000);
y_tan = (4.*x_tan)-4;

x_tan2 = linspace(2.5,6, 1000);
y_tan2 = ((0.25).*x_tan2)+1;

hold on
 
plot(x, y, "b-", "Linewidth", 1.5);

plot(x1, y1, "y-","Linewidth", 1.5);

plot(x_tan, y_tan,"r","Linewidth", 1.5);
plot(x_tan2, y_tan2,"r","Linewidth", 1.5);

plot (x_vert1, y_vert2, "m--");
plot (x_vert2, y_vert1,"m--");

text(2,4,'\leftarrow slope 4 (2,4)')
text(2.4,5.3,' y=x^2, x>0')
text(5.3,2.3,' y= x^{0.5}')
text(4,2.2,'slope 0.25 (4,2) \downarrow', "HorizontalAlignment", "right")


