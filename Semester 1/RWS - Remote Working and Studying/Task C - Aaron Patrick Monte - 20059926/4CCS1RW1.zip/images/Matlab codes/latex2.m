clear;
clc;
x = linspace(0,2.5, 1000);
y = (x.^3)-2;

x1 = linspace(-2,6.3, 1000);
y1 =  (x1+2).^(1/3);

x_vert1 = linspace(6, 6, 1000);
y_vert2 = linspace(0, 2, 1000);

x_tan = linspace(1.7,2.07, 1000);
y_tan = (12.*x_tan)-18;

x_tan2 = linspace(2.3,6.2, 1000);
y_tan2 = ((1/12).*x_tan2)+1.5;

axis equal
axis ([-2,7, -2,7])
set(gca, 'XAxisLocation', 'origin', 'YAxisLocation', 'origin')

hold on
 
plot(x, y, "b-", "Linewidth", 1.5);

plot(x1, y1, "y-","Linewidth", 1.5);

plot(x_tan, y_tan,"r","Linewidth", 1.5);
plot(x_tan2, y_tan2,"r","Linewidth", 1.5);

plot(x_vert1,y_vert2, "m--");


text(2.2,6.5,'y = x^3-2 ')
text(2.2,6,'Slope 3x^2= 3(2)^2 = 12')
text(1.3,6,'(2,6)\rightarrow ')

text(2.4,5.3,' ')
text(6.2,2.3,' Reciprocal slope: 1/12',"HorizontalAlignment", "right")
text(6,1.7,'\uparrow(6,2)')

